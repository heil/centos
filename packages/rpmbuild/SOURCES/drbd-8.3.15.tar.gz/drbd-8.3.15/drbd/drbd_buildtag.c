/* automatically generated. DO NOT EDIT. */
#include <linux/drbd.h>
const char *drbd_buildtag(void)
{
	return "GIT-hash: 0ce4d235fc02b5c53c1c52c53433d11a694eab8c"
		" build by phil@fat-tyre, 2012-12-18 13:12:24";
}
