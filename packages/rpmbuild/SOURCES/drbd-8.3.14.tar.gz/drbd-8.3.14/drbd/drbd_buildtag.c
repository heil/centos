/* automatically generated. DO NOT EDIT. */
#include <linux/drbd.h>
const char *drbd_buildtag(void)
{
	return "GIT-hash: 3fc56aae927694b31eb959d922c9eec3f491f75c"
		" build by phil@fat-tyre, 2012-10-19 11:10:12";
}
