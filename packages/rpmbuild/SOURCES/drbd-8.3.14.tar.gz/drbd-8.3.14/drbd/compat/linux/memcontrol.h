/* just an empty file
 * memcontrol.h did not exist prior to 2.6.25.
 * but it needs more recent kernels for mm_inline.h to work. */
